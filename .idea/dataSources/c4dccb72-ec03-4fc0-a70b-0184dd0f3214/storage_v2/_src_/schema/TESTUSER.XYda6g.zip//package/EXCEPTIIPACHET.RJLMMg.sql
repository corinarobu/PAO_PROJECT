create PACKAGE ExcepțiiPachet AS
    -- Excepție pentru cazul în care clientul nu este găsit
    CLIENTNOTFOUNDEXCEPTION EXCEPTION;
    PRAGMA EXCEPTION_INIT(CLIENTNOTFOUNDEXCEPTION, -20101);

    -- Excepție pentru erori în procesarea datelor
    DataProcessingException EXCEPTION;
    PRAGMA EXCEPTION_INIT(DataProcessingException, -20102);
END ExcepțiiPachet;
/

