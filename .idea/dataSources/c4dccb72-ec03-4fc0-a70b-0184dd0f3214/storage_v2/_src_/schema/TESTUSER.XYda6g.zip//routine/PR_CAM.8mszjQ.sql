create FUNCTION pr_cam
 (v_nr camera.numar_camera%TYPE DEFAULT 111) 
RETURN NUMBER IS
 pretul camera.pret%type; 
 BEGIN
 SELECT pret INTO pretul 
 FROM camera
 WHERE numar_camera = v_nr;
 RETURN pretul;
 EXCEPTION
 WHEN NO_DATA_FOUND THEN
 RAISE_APPLICATION_ERROR(-20000,
 'Nu exista camera cu numarul dat');
 WHEN TOO_MANY_ROWS THEN
 RAISE_APPLICATION_ERROR(-20001,
 'Exista mai multe camere cu numarul dat');
 WHEN OTHERS THEN
 RAISE_APPLICATION_ERROR(-20002,'Alta eroare!');
END pr_cam;
/

