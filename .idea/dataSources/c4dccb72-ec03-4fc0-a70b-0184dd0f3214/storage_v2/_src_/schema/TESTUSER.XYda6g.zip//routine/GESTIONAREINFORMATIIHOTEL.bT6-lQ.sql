create PROCEDURE GestionareInformatiiHotel(p_id_client IN NUMBER) 
IS
      TYPE DetaliiCamera IS RECORD (
     numar_camera camera.numar_camera%TYPE,
     tip_camera camera.tip_camera%TYPE );

 TYPE CamereTablouIndexat IS TABLE OF DetaliiCamera INDEX BY PLS_INTEGER;

     TYPE DetaliiRezervare IS RECORD (
     id_rezervare rezervare.id_rezervare%TYPE,
     data_cazare rezervare.data_cazare%TYPE,
     data_plecare rezervare.data_plecare%TYPE,
     detalii_camera DetaliiCamera);

 TYPE RezervariTablouImbricat IS TABLE OF DetaliiRezervare;

    TYPE DetaliiPlata IS RECORD (
     id_plata plata.id_plata%TYPE,
     statut plata.statut%TYPE,
    modalitate_plata plata.modalitate%TYPE);

 TYPE PlatiVector IS VARRAY(10) OF DetaliiPlata;

   v_camere_info CamereTablouIndexat;
   v_rezervari_info RezervariTablouImbricat := RezervariTablouImbricat(); -- Inițializare  colecție în mod nested
   v_plati_info PlatiVector := PlatiVector(); -- Inițializare vector
   v_total_consum NUMBER := 0;
BEGIN

 -- Gestionarea rezervărilor (tablou indexat)
       FOR info_rezervare IN (SELECT r.*, c.tip_camera
       FROM rezervare r
      JOIN camera c ON r.numar_camera = c.numar_camera
      WHERE r.id_client = p_id_client) 
   LOOP
     v_camere_info(info_rezervare.id_rezervare).numar_camera :=  info_rezervare.numar_camera;
      v_camere_info(info_rezervare.id_rezervare).tip_camera := info_rezervare.tip_camera;

 -- Gestionarea rezervărilor (tablou în mod nested)
     v_rezervari_info.EXTEND;
     v_rezervari_info(v_rezervari_info.LAST).id_rezervare := info_rezervare.id_rezervare;
     v_rezervari_info(v_rezervari_info.LAST).data_cazare := info_rezervare.data_cazare;
     v_rezervari_info(v_rezervari_info.LAST).data_plecare := info_rezervare.data_plecare;
     v_rezervari_info(v_rezervari_info.LAST).detalii_camera := 
    v_camere_info(info_rezervare.id_rezervare);


   DBMS_OUTPUT.PUT_LINE('Detalii rezervare ' || ': ' ||
    'data de cazare: ' ||  v_rezervari_info(v_rezervari_info.LAST).data_cazare || ', ' ||
    'data de plecare: ' || v_rezervari_info(v_rezervari_info.LAST).data_plecare || ', ' ||
    'in camera cu numarul ' || v_camere_info(info_rezervare.id_rezervare).numar_camera || ', ' ||
    'tip camera: ' ||  v_camere_info(info_rezervare.id_rezervare).tip_camera);


 -- Gestionarea plăților (vector)
    v_plati_info := PlatiVector(); -- Inițializare vector
     FOR info_plata IN (SELECT p.id_plata, p.modalitate, p.statut
     FROM plata p 
    WHERE p.id_rezervare = info_rezervare.id_rezervare) 
   LOOP
     v_plati_info.EXTEND;
     v_plati_info(v_plati_info.LAST).id_plata := info_plata.id_plata;
     v_plati_info(v_plati_info.LAST).statut := info_plata.statut;
      v_plati_info(v_plati_info.LAST).modalitate_plata :=info_plata.modalitate;
   END LOOP;

    FOR i IN v_plati_info.FIRST..v_plati_info.LAST LOOP
        if v_plati_info(i).statut = 'neplatita' then
              DBMS_OUTPUT.PUT_LINE('Plata ID ' || v_plati_info(i).id_plata || ', Statut de plata: ' || v_plati_info(i).statut);
       else 
             DBMS_OUTPUT.PUT_LINE('Plata ID ' || v_plati_info(i).id_plata || ', Statut de plata: ' || v_plati_info(i).statut || ', Modalitate de plata: ' || v_plati_info(i).modalitate_plata);
      end if;
    END LOOP;

 -- Resetăm colecțiile pentru următoarea iterație
     v_plati_info.DELETE;
 END LOOP;

   IF v_rezervari_info.COUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Clientul nu are rezervari.');
   END IF;
EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);
END GestionareInformatiiHotel;
/

