create PROCEDURE AdaugaRecenzie (
    p_id_client IN NUMBER,
    p_id_produs IN NUMBER,
    p_text_recenzie IN VARCHAR2,
    p_nota_recenzie IN NUMBER
) AS
    TYPE RecenziiVector IS TABLE OF VARCHAR2(200);
    TYPE ProduseIndexate IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
    TYPE RecenzieDetaliata IS OBJECT (
        text_recenzie VARCHAR2(200),
        nota_recenzie NUMBER
    );
    TYPE RecenziiDetaliate IS TABLE OF RecenzieDetaliata;

    v_recenzii_produs RecenziiVector;
    v_produse ProduseIndexate;
    v_recenzii_detaliate RecenziiDetaliate;
BEGIN
    -- Verificăm dacă produsul există deja în tabloul indexat
    IF v_produse.EXISTS(p_id_produs) THEN
        -- Dacă produsul există, adăugăm recenzia la vectorul corespunzător
        v_recenzii_produs := RecenziiVector();
        SELECT R.text_recenzie, R.nota_recenzie
        BULK COLLECT INTO v_recenzii_produs
        FROM Recenzii R
        WHERE R.id_produs = p_id_produs;

        v_recenzii_produs.EXTEND;
        v_recenzii_produs(v_recenzii_produs.LAST) := p_text_recenzie;

        -- Actualizăm recenziile în baza de date
        UPDATE Recenzii
        SET text_recenzie = v_recenzii_produs,
            nota_recenzie = p_nota_recenzie
        WHERE id_produs = p_id_produs;

    ELSE
        -- Dacă produsul nu există în tabloul indexat, îl adăugăm
        v_produse(p_id_produs) := 1;

        -- Adăugăm o nouă recenzie
        v_recenzii_detaliate := RecenziiDetaliate(
            RecenzieDetaliata(p_text_recenzie, p_nota_recenzie)
        );

        FOR i IN 1..v_recenzii_detaliate.COUNT LOOP
            INSERT INTO Recenzii (id_produs, text_recenzie, nota_recenzie)
            VALUES (p_id_produs, v_recenzii_detaliate(i).text_recenzie, v_recenzii_detaliate(i).nota_recenzie);
        END LOOP;
    END IF;
END AdaugaRecenzie;
/

