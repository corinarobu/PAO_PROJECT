create PROCEDURE subprogram_interactiune_clienti(
   p_data_inceput DATE,
   p_data_sfarsit DATE,
   p_id_angajat NUMBER
) IS

 -- Tabel indexat pentru a stoca ID-urile clientilor deja afisati
       TYPE clienti_afisati IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
       v_clienti_afisati clienti_afisati;

   -- clientii corespunzatori pt rezervarile aflate, si care au interactionat cu angajatul mentionat
   CURSOR cur_clienti_interactiune (p_id_rezervare NUMBER) IS
      SELECT DISTINCT c.id_client, c.nume_client, c.email, c.numar_telefon
      FROM Client c
      WHERE EXISTS (
            SELECT 1
            FROM Rezervare r
            Join Client cl on r.id_client = cl.id_client
            JOIN Plata p ON r.id_rezervare = p.id_rezervare
            JOIN Interactioneaza ci ON cl.id_client = ci.id_client
            WHERE r.id_rezervare = p_id_rezervare   
            AND ci.id_angajat = p_id_angajat
            AND c.id_client = cl.id_client
         );


   v_info_client VARCHAR2(100);
   v_client_exista NUMBER := 0; 

BEGIN

  FOR info_rezervare IN  ( SELECT DISTINCT p.id_rezervare
                          FROM Plata p
                          WHERE p.statut = 'platita' AND p.id_rezervare IN (
                                SELECT r.id_rezervare
                                FROM Rezervare r
                                WHERE r.data_cazare BETWEEN p_data_inceput AND p_data_sfarsit) )
                    LOOP
       FOR info_client IN cur_clienti_interactiune(info_rezervare.id_rezervare) LOOP

            IF v_clienti_afisati.EXISTS(info_client.id_client) THEN
                    CONTINUE; -- Trecem la urmatoarea iteratie daca deja a fost afisat
             ELSE
                -- Adaugam ID-ul clientului in tabelul indexat, sa il omitem daca viitoare
                v_clienti_afisati(info_client.id_client) := 1;
             END IF;

             v_info_client := 'Nume: ' || info_client.nume_client ||
                              ', Email: ' || info_client.email ||
                              ', Numar Telefon: ' || info_client.numar_telefon;

             v_client_exista := 1; -- am afisat macar 1 client


            DBMS_OUTPUT.PUT_LINE('Client implicat: ' || v_info_client);
      END LOOP;
   END LOOP;

    If v_client_exista = 0 then
        DBMS_OUTPUT.PUT_LINE('nu exista clienti');
   end if;

EXCEPTION
   WHEN OTHERS THEN
      -- In caz de eroare, afisam un mesaj de eroare
      DBMS_OUTPUT.PUT_LINE('Eroare: ' || SQLERRM);
END subprogram_interactiune_clienti;
/

