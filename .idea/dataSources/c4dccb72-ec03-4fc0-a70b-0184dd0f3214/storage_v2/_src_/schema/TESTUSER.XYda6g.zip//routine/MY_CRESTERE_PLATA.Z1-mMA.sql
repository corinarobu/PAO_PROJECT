create PROCEDURE my_crestere_plata
 (v_numar info_camere.numar%TYPE,
 v_plati info_camere.plati%TYPE) AS
BEGIN
 UPDATE info_camere
 SET plati = NVL (plati, 0) + v_plati
 WHERE id = v_numar;
END;
/

