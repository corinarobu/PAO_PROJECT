create FUNCTION CalculZileCazare(p_id_client IN NUMBER) 
RETURN NUMBER IS
    v_zile_cazare NUMBER;
    v_client_exist NUMBER;
   v_client_a_rezervat NUMBER := 0;

    ClientNotFoundException2 EXCEPTION;
    ClientNotCheckedInException2 EXCEPTION;
    ClientIdTooLargeException2 EXCEPTION; 
    NoPaymentException2 EXCEPTION;  
BEGIN
      IF LENGTH(TO_CHAR(p_id_client)) > 3 THEN
        RAISE ClientIdTooLargeException2;
    END IF;

  -- 0 cand clientul - exista - dar nu a platit sau nu a rezervat 
    -- 0 cand clientul - nu exista
    SELECT nvl(SUM(r.data_plecare - r.data_cazare),0)
    INTO v_zile_cazare
    FROM rezervare r
    JOIN client c ON r.id_client = c.id_client
    JOIN plata p ON r.id_rezervare = p.id_rezervare
    WHERE r.id_client = p_id_client
    and p.statut = 'platita';

    select count(*) 
    into v_client_exist
    from client where
    id_client = p_id_client; -- != 0 daca clientul exista

    SELECT count(*)
    INTO v_client_a_rezervat
    FROM rezervare r
    WHERE r.id_client = p_id_client;


    IF v_zile_cazare = 0 THEN  
      if v_client_exist = 0 THEN-- nu exista
            RAISE ClientNotFoundException2;
      else -- exista
           IF v_client_a_rezervat != 0 THEN -- nu are plati efectuate, dar a rezervat
                RAISE NoPaymentException2;
           else 
              RAISE ClientNotCheckedInException2;  -- nu a facut inca rezervar
           end if;
     end if;
    END IF;

    RETURN v_zile_cazare;

EXCEPTION
     WHEN ClientNotFoundException2 THEN
        DBMS_OUTPUT.PUT_LINE('Clientul nu exista');
        RAISE_APPLICATION_ERROR(-20001, 'Nu există clientul cu numărul dat.');
    WHEN ClientNotCheckedInException2 THEN -- nu a rezervat sau inca nu a plecat deci plata nu s-a facut
        DBMS_OUTPUT.PUT_LINE('Clientul nu a facut încă nicio rezervare.');
        RAISE_APPLICATION_ERROR(-20002, 'Clientul nu a facut încă nicio rezervare');
    WHEN ClientIdTooLargeException2 THEN
        DBMS_OUTPUT.PUT_LINE('Id-ul clientului nu poate fi mai mare de 3 cifre.');
        RAISE_APPLICATION_ERROR(-20004, 'Id-ul clientului nu poate fi mai mare de 3 cifre.');
   WHEN NoPaymentException2 THEN
        DBMS_OUTPUT.PUT_LINE('Clientul nu a platit');
        RAISE_APPLICATION_ERROR(-20005, 'Clientul nu are plati efectuate pe nicio rezervare facuta');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Alta eroare');
        RAISE_APPLICATION_ERROR(-20003, 'Altă excepție.');
END CalculZileCazare;
/

