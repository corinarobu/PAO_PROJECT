create PROCEDURE CalculCosturiTotale(p_nume_client IN VARCHAR2) IS 
  v_cost_total NUMBER;
  v_client_id NUMBER;
  v_client_spent NUMBER;
BEGIN
  -- Obține id-ul clientului bazat pe nume 
  SELECT id_client 
  INTO v_client_id 
  FROM Client
  WHERE nume_client = p_nume_client;

  IF v_client_id IS NULL THEN
    RAISE TOO_MANY_ROWS;
  END IF;

  -- Verifică dacă există prea multe înregistrări
  BEGIN
    SELECT COUNT(id_comanda_rezervare) 
    INTO v_client_spent
    FROM (
      SELECT co.id_comanda AS id_comanda_rezervare
      FROM Comanda co
      JOIN contine con ON co.id_comanda = con.id_comanda
      WHERE co.id_client = v_client_id
      UNION
      SELECT id_rezervare AS id_comanda_rezervare
      FROM Rezervare
      WHERE id_client = v_client_id
    );
  EXCEPTION
    WHEN OTHERS THEN
      RAISE TOO_MANY_ROWS;
      RETURN; -- se opreste executia daca sunt prea multe randuri
  END;

  -- incepand de aici intra doar daca exista si e unic (a cheluit sau nu)


  IF v_client_spent > 0 THEN -- a cheltuit, si calculam cat
    SELECT NVL(SUM(ca.pret * (re.data_plecare - re.data_cazare)), 0) + NVL(SUM(pr.pret), 0)
    INTO v_cost_total 
    FROM Client cl
    LEFT JOIN Rezervare re ON cl.id_client = re.id_client
    LEFT JOIN Camera ca ON ca.numar_camera = re.numar_camera
    LEFT JOIN Comanda co ON co.id_client = cl.id_client
    LEFT JOIN Contine cont ON co.id_comanda = cont.id_comanda
    LEFT JOIN Produs pr ON cont.id_produs = pr.id_produs
    WHERE cl.id_client = v_client_id;
  END IF;

  IF v_cost_total is null THEN -- exista dar nu a cheltuit
    RAISE MyExceptions.ClientHasNoSpendingException;
  END IF;

  DBMS_OUTPUT.PUT_LINE('Costuri totale pentru clientul cu numele ' || p_nume_client || ': ' || v_cost_total);

EXCEPTION
   WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Nu există');
    RAISE_APPLICATION_ERROR(-20000, 'Nu există clientul cu numele dat');
  WHEN MyExceptions.ClientHasNoSpendingException THEN
    DBMS_OUTPUT.PUT_LINE('Nu a cheltuit');
    RAISE_APPLICATION_ERROR(-20001, 'Clientul cu numele dat nu a rezervat și nu a comandat nimic');
  WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE('Prea mulți clienți cu numele dat');
    RAISE_APPLICATION_ERROR(-20002, 'Prea mulți clienți cu cu numele dat');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Alta eroare');
    RAISE_APPLICATION_ERROR(-20002, 'Alta excepție');
END CalculCosturiTotale;
/

