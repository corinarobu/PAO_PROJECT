create TYPE NumarList IS TABLE OF NUMBER;
CREATE TYPE Varchar2List IS TABLE OF VARCHAR2(100);

CREATE OR REPLACE PROCEDURE AdaugaComanda (
    p_id_client IN NUMBER,
    p_data_comanda IN DATE,
    p_loc_servire IN VARCHAR2,
    p_produse IN NumarList,
    p_cantitati IN NumarList
) AS
    v_id_comanda NUMBER;
    v_detalii_comanda SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST();
BEGIN
    -- Obțineți un ID unic pentru comanda nouă
    SELECT SEQ_COMANDA.NEXTVAL INTO v_id_comanda FROM DUAL;

    -- Inserează comanda în tabelul Comanda
    INSERT INTO Comanda (id_comanda#, data_comanda, loc_servire, id_client)
    VALUES (v_id_comanda, p_data_comanda, p_loc_servire, p_id_client);

    -- Iterați prin produsele din comandă și inserați detalii în tabelul Detaliu_Comanda
    FOR i IN 1..p_produse.COUNT LOOP
        v_detalii_comanda := SYS.ODCIVARCHAR2LIST();  -- Resetăm lista pentru fiecare produs

        -- Adăugați detalii despre produs
        v_detalii_comanda.EXTEND;
        v_detalii_comanda(v_detalii_comanda.LAST) := 'ID_PRODUS: ' || p_produse(i) || ', CANTITATE: ' || p_cantitati(i);

        -- Inserați detalii în tabelul Detaliu_Comanda
        INSERT INTO Detaliu_Comanda (id_comanda#, id_produs#, cantitate)
        VALUES (v_id_comanda, p_produse(i), p_cantitati(i));
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Comanda adaugata cu succes! ID Comanda: ' || v_id_comanda);
END AdaugaComanda;
/

