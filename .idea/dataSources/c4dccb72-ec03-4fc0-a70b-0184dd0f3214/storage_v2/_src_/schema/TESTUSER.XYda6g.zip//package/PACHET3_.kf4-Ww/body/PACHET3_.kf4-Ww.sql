create PACKAGE BODY pachet3_*** AS
CURSOR c_emp(nr NUMBER) RETURN employees%ROWTYPE
 IS
 SELECT *
 FROM employees
 WHERE salary >= nr;
FUNCTION f_max (v_oras locations.city%TYPE) RETURN NUMBER IS
 maxim NUMBER;
BEGIN
 SELECT MAX(salary)
 INTO maxim
 FROM employees e, departments d, locations l
 WHERE e.department_id=d.department_id
 AND d.location_id=l.location_id
 AND UPPER(city)=UPPER(v_oras);
 RETURN maxim;
END f_max;
END pachet3_***;
/

